document.addEventListener("DOMContentLoaded", () => {
    let preguntasGlobal = [];

    const idInput = document.getElementById("id");
    const apellidosInput = document.getElementById("apellidos");
    const nombreInput = document.getElementById("nombre");
    const iniciarExamenBtn = document.getElementById("iniciarExamen");
    const finalizarExamenBtn = document.getElementById("finalizarExamen");
    const contenidoExamen = document.getElementById("contenidoExamen");
    const buscarEstudianteBtn = document.getElementById("buscarEstudiante");
    const formExamen = document.getElementById("formExamen");

    buscarEstudianteBtn.addEventListener("click", buscarEstudiante);
    iniciarExamenBtn.addEventListener("click", iniciarExamen);
    finalizarExamenBtn.addEventListener("click", calificarExamen);


    // Buscar estudiante
    function buscarEstudiante() {
        const id = idInput.value;
        if (!id) return alert("Por favor, ingrese un ID");

        const estudiante = JSON.parse(localStorage.getItem("estudiante"));

        if (estudiante && estudiante.id === id) {
            apellidosInput.value = estudiante.apellidos;
            nombreInput.value = estudiante.nombre;
            alert(`Estudiante encontrado: ${estudiante.nombre} ${estudiante.apellidos}`);
        } else {
            alert("No se ecnontró");
        }
    }

    // Iniciar Examen
    async function iniciarExamen() {
        const id = idInput.value;
        const apellidos = apellidosInput.value;
        const nombre = nombreInput.value;

        if (!id || !apellidos || !nombre) return alert("Complete todos los campos");

        // Cargar estudiante anterior o crear nuevo
        let estudiante = JSON.parse(localStorage.getItem("estudiante")) || {};

        // Si es el mismo estudiante se aumenta el intenta
        if(estudiante.id === id) {
            estudiante.intento++
        } else {
            estudiante = { id, apellidos, nombre, intento: 1 };
        }

        // Guardar estudiante 
        localStorage.setItem("estudiante", JSON.stringify(estudiante));
        alert(`Examen iniciado para ${nombre} ${apellidos} - Intento ${estudiante.intento}`);

        formExamen.style.display = "block";
        const data = await leerPreguntas();
        mostrarPreguntas(data.preguntas);
    }

    // Leer preguntas
    async function leerPreguntas() {
        const res = await fetch("preguntas.json");
        return await res.json();
    }

    // Mostrar preguntas
    function mostrarPreguntas(preguntas) {
        preguntasGlobal = preguntas;
        contenidoExamen.innerHTML = preguntas.map(p => `
          <div class="pregunta">
            <p><strong>${p.id}. ${p.pregunta}</strong></p>
            <div class="opciones">
              ${p.opciones.map(opcion => `
                <label>
                  <input type="radio" name="pregunta${p.id}" value="${opcion}">
                  ${opcion}
                </label>
              `).join("")}
            </div>
          </div>
        `).join("");
    }

    // Calificar examen
    function calificarExamen() {
        if (!preguntasGlobal.length) return;

        let correctas = 0;
        preguntasGlobal.forEach(p => {
            const seleccionada = document.querySelector(`input[name="pregunta${p.id}"]:checked`);
            if (seleccionada.value === p.respuesta_correcta) correctas++;
        });

        const porcentaje = Math.round((correctas / preguntasGlobal.length) * 100);
        alert(`Calificacion: ${correctas}/${preguntasGlobal.length} (${porcentaje}%)`);

    }

});